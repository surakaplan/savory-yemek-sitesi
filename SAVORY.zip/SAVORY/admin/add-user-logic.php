<?php

require 'config/database.php';

//butona basıldıgında verileri yukleme

if(isset($_POST['submit'])) {
    $firstname = filter_var($_POST['firstname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $lastname = filter_var($_POST['lastname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $username = filter_var($_POST['username'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $createpassword = filter_var($_POST['createpassword'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $confirmpassword = filter_var($_POST['confirmpassword'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $is_admin = filter_var($_POST['userrole'], FILTER_SANITIZE_NUMBER_INT);
    $avatar = $_FILES['avatar'];

    //giris değerlerini doğrula
    if(!$firstname){
        $_SESSION['add-user'] = "Lütfen adınızı giriniz";
    }
    else if (!$lastname) {
        $_SESSION['add-user'] = "Lütfen Soyadınızı giriniz";

    }
    else if (!$username) {
        $_SESSION['add-user'] = "Lütfen Kullanıcı adınızı giriniz";

    }
    else if (!$email) {
        $_SESSION['add-user'] = "Lütfen geçerli e-postanızı giriniz";

    }
    
    else if (strlen($createpassword)< 8 || strlen($confirmpassword) < 8) {
        $_SESSION['add-user'] = "Şifreniz 8+ karakter olmalıdır";

    }
    else if (!$avatar['name']) {
        $_SESSION['add-user'] = "Lütfen avatar ekleyiniz";

    }
    else{  //sifre eşleşiyor mu kontrol et
        if($createpassword !== $confirmpassword){
            $_SESSION['signup'] =  "şifreler eşleşmiyor";
        }
        else{ 

            $hashed_password = password_hash($createpassword,PASSWORD_DEFAULT);

            //username ya da email database de var mı kontrol et
            $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email'";
            $user_check_result = mysqli_query($connection, $user_check_query);

            if (mysqli_num_rows($user_check_result) > 0 ){
                $_SESSION['add-user'] = "Kullanıcı adı zaten var";
            }
            else{
                //AVATAR
                //avatar adı değisme

                $time = time();
                $avatar_name = $time . $avatar['name'];
                $avatar_tmp_name = $avatar['tmp_name'];
                $avatar_destination_path = '../images/'. $avatar_name;

                //dosyaya ekleme
                $allowed_files = ['png','jpg','jpeg'];
                $extention = explode('.', $avatar_name);
                $extention = end($extention);

                if(in_array($extention,$allowed_files)){
                    //avatar boyutu 1mb+ olamaz
                    if($avatar['size'] < 100000) {
                        //avatar yükleme
                        move_uploaded_file($avatar_tmp_name, $avatar_destination_path);
                        

                    }
                    else{
                        $_SESSION['add-user'] = "Dosya boyutu çok büyük. 1mb'dan küçük olmalı";
                    }
                }
                else{
                    $_SESSION['add-user'] = "Dosya uzantısı png, jpg ya da jpeg olmalıdır";
                }
             }
        } 

    }
    //sorun varsa add-user sayfasına geri döndürme
    if(isset($_SESSION['add-user'])) {

        $_SESSION['add-user-data'] = $_POST;
        header('location: ' . ROOT_URL . '/admin/add-user.php');
        die();
    }
    else{
        //yeni kullanıcıyı users tabloya ekleme
        $insert_user_query = "INSERT INTO users SET firstname='$firstname', lastname='$lastname', username='$username',
         email='$email', password='$hashed_password', avatar='$avatar_name', is_admin=$is_admin";
        
        $insert_users_result = mysqli_query($connection, $insert_user_query);
        
        if(!mysqli_errno($connection)){
            //basarılı mesajıyla  sayfasına
            $_SESSION['add-user-success'] = "Yeni kullanıcı $firstname $lastname eklendi";
            header('Location: ' . ROOT_URL . 'admin/manage-users.php');
            die();
            
        }

    }
    
}


else {
    //butona basılmazsa signup sayfasına
    header('location:' . ROOT_URL . 'admin/add-user.php');
    die();
}

