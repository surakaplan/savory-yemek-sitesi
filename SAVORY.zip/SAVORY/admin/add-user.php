<?php
require 'config/database.php';
//databaseden getirme
if(isset($_SESSION['user-id'])) {
    $id = filter_var($_SESSION['user-id'], FILTER_SANITIZE_NUMBER_INT);
    $query = "SELECT avatar FROM users WHERE id=$id";
    $result = mysqli_query($connection, $query);
    $avatar = mysqli_fetch_assoc($result);
}

$firstname = $_SESSION['add-user-data']['firstname'] ?? null;
$lastname = $_SESSION['add-user-data']['lastname'] ?? null;
$username = $_SESSION['add-user-data']['username'] ?? null;
$email = $_SESSION['add-user-data'] ['email']?? null;
$createpassword = $_SESSION['add-user-data'] ['createpassword'] ?? null;
$confirmpassword = $_SESSION['add-user-data'] ['confirmpassword'] ?? null;



unset($_SESSION['add-user-data']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAVORY</title>
    <link rel="stylesheet" href="<?= ROOT_URL ?>css/style.css">
    <!--font awesome CDN-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha384-rAt2dDO9LsmTBpGlczN7ioGVEUb7F6WTpVlX1eCjzFLcN0N4Gqewd7qUdciMK9e" crossorigin="anonymous">
    <!--iconscout cdn-->    
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css"> 
    <!--google fonts-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:opsz,wght@6..12,200&family=Poppins:ital,wght@0,200;0,300;0,400;0,600;0,700;1,800&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="cookie.ico" type="image/x-icon">
</head>
<body>
    <nav>
        <div class="container nav__container">
            <a href="<?= ROOT_URL ?>" class="nav__logo">Savory</a>
            <ul class="nav__items">
                <li><a href="<?= ROOT_URL ?>index.php">Ana Sayfa</a></li>
                <li><a href="<?= ROOT_URL ?>recipes.php">Tarifler</a></li>
                <li><a href="<?= ROOT_URL ?>about.php">Hakkında</a></li>
                <li><a href="<?= ROOT_URL ?>contact.php">İletişim</a></li>
                <?php if(isset($_SESSION['user-id'])) : ?>
                    <li class="nav__profile">
                        <div class="avatar">
                            <img src="<?= ROOT_URL . 'images/' . $avatar['avatar'] ?>">
                        </div>
                      <ul>
                             <li><a href="<?= ROOT_URL ?>admin/index.php">Gösterge paneli</a></li>
                             <li><a href="<?= ROOT_URL ?>logout.php">Çıkış</a></li>
                     </ul>
                    </li>
                <?php else : ?>
                    <li><a href="<?= ROOT_URL ?>signin.php">Giriş</a></li> 
                <?php endif ?>
            </ul>
                
            <button id="open__nav-btn"><i class="uil uil-bars"></i></button>
            <button id="close__nav-btn"><i class="uil uil-times"></i></button>

        </div>
    </nav>
    <!--nav bar sonu-->

<style>

.form__section{
   font-family: 'Poppins', sans-serif;
   display: grid;
   place-items: center;
   height: 100vh;
   margin-bottom: 250px;
   
}
.form__section-container{
   width: var(--form-width);

}
.alert{
   padding: 0.8rem 1.4rem;
   margin-bottom: 1rem;
   border-radius: var(--card-border-radius-2);
   
}
.alert.error{
   background: var(--color-red-light);
   color: var(--color-red);
}
.alert.success{
   background: var(--color-green-light);
   color: white;
   
}
form{
   font-family: 'Poppins', sans-serif;
   display: flex;
   flex-direction: column;
   gap: 1rem;
   margin: 1rem;
   
   
}
.form__control{
   display: flex;
   flex-direction: column;
   gap: 0.6rem;
   
}
.form__control.inline{
    flex-direction: row;
    align-items: center;
}

input, textarea, select{
   padding:0.8rem 1.4rem;
   background-color:  #5854c7a9;
   border-radius: var(--card-border-radius-2);
   resize: none;
   color: var(--color-white);
   font-family: 'Poppins', sans-serif;

}
input::placeholder {
    color: #ffffff; /* İstenilen renk */
}

.form__section small{
    margin-top: 1rem;
    display: block;
}
.form__section small a{
    color:whitesmoke;

}

.subtn{
    
    display: inline-block;
    width: fit-content;
    padding: 0.6rem 1.2rem;
    background-color: var(--color-primary);
    border-radius: var(--card-border-radius-2);
    cursor: pointer;
    transition: var(--transition);
    color: var(--color-white);
}
h2{
    text-align: center;
    padding-top: 2rem;
}

</style>

    <section class="form__section" style="font-family: 'Poppins', sans-serif; padding-bottom: 5.5rem;">
        <div class="container form__section-container">
            <h2>Kullanıcı Ekleme</h2>
            <?php if(isset($_SESSION['add-user'])) : ?>
                <div class="alert error">
                    <p>
                        <?= $_SESSION['add-user'];
                        unset($_SESSION['add-user']);
                        ?>
                    </p>
                </div>

            <?php endif ?>
        
        <form action="<?= ROOT_URL ?>admin/add-user-logic.php" method="POST" enctype="multipart/form-data" style="font-family: 'Poppins', sans-serif;">
            <input type="text" name="firstname" value="<?=$firstname?>" placeholder="Ad">
            <input type="text"  name="lastname" value="<?=$lastname?>" placeholder="Soyad">
            <input type="text"  name="username" value="<?=$username?>" placeholder="Kullanıcı Adı">
            <input type="email"  name="email" value="<?=$email?>" placeholder="Email">
            <input type="password"  name="createpassword" value="<?=$createpassword?>" placeholder="Şifre Oluştur">
            <input type="password"  name="confirmpassword" value="<?=$confirmpassword?>"  placeholder="Şifreyi Doğrulayın">

            <select name="userrole" >
                <option value="0">Üye</option>
                <option value="1">Admin</option>
            </select>
            <div class="form__control">
                <label for="avatar">Kullanıcı Avatarı</label>
                <input type="file" name="avatar" id="avatar">
            </div>
            <button type="submit" name="submit" class="subtn">Kullanıcı Ekle</button>
        </form>
        </div>
    </section>
    




<?php
include '../partials/footer.php';
?>



</body>
</html>

</body>