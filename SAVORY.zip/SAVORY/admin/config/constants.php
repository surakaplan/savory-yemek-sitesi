<?php
session_start();

define('ROOT_URL','http://localhost/SAVORY/');
define('DB_HOST', 'localhost');
define('DB_USER', 'suranur');
define('DB_PASS', 'admin123');
define('DB_NAME', 'savory');