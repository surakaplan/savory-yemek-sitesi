<?php
require 'config/database.php';

if(isset($_POST['submit'])) {
    $author_id = $_SESSION['user-id'];
    $title = filter_var($_POST['title'], FILTER_SANITIZE_SPECIAL_CHARS);
    $body = filter_var($_POST['body'], FILTER_SANITIZE_SPECIAL_CHARS);
    $category_id = filter_var($_POST['category'], FILTER_SANITIZE_NUMBER_INT);
    $is_featured = filter_var($_POST['is_featured'], FILTER_SANITIZE_NUMBER_INT);
    $resim = $_FILES['resim'];

    //kontrol edilmemişse is featured
    $is_featured = $is_featured == 1 ?: 0;

    //verileri dogrulama
    if(!$title) {
        $_SESSION['add-post'] ="Tarif başlığı giriniz";
    }
    elseif(!$category_id){
        $_SESSION['add-post'] = "Tarif kategorisi seçiniz";
    }
    elseif(!$body){
        $_SESSION['add-post'] = "Tarif açıklaması yazınız";
    }
    elseif(!$resim['name']){
        $_SESSION['add-post'] = "Tarifiniz için resim ekleyiniz";
    }
    else{
        //yeniden isimlendir resmi
        $time = time(); //benzersiz isim yapma
        $resim_name = $time . $resim['name'];
        $resim_tmp_name = $resim['tmp_name'];
        $resim_destination_path = '../images/' . $resim_name;

        //Resim olduguna emin ol
        $allowed_files = ['png','jpg','jpeg'];
                $extention = explode('.', $resim_name);
                $extention = end($extention);

                if(in_array($extention,$allowed_files)){
                    //resim boyutu 2mb+ olamaz
                    if($resim['size'] < 2000000) {
                        //resim yükleme
                        move_uploaded_file($resim_tmp_name, $resim_destination_path);
                        

                    }
                    else{
                        $_SESSION['add-post'] = "Dosya boyutu çok büyük. 2mb'dan küçük olmalı";
                    }
                }
                else{
                    $_SESSION['add-post'] = "Dosya uzantısı png, jpg ya da jpeg olmalıdır";
                }
        }
    //sorun varsa AYNI SAYFAYA VERİLERLE GERİ DÖNDURME
    if(isset($_SESSION['add-post'])){
        $_SESSION['add-post-data'] = $_POST;
        header('location: ' . ROOT_URL . 'admin/add-post.php');
        die();
    }
    
    else{
        // eger bu gönderi öne cıkmıssa(1) diger hepsini 0 yap
        if($is_featured == 1){
        $zero_all_is_featured_query = "UPDATE posts SET is_featured=0";
        $zero_all_is_featured_result = mysqli_query($connection, $zero_all_is_featured_query);

        }
        //database e post ekle
        $query = "INSERT INTO posts (title, body, resim, category_id, author_id, is_featured) 
        VALUES ('$title', '$body', '$resim_name', $category_id, $author_id, $is_featured)";
        $result = mysqli_query($connection,$query);

        if(!mysqli_errno($connection)) {
            $_SESSION['add-post-success'] = "Yeni tarif başarıyla eklendi";
            header('location: ' . ROOT_URL . 'admin/');
            die();
        }
    }
}

header('location: ' . ROOT_URL . 'admin/add-post.php');
die();
