<?php
require 'config/database.php';

if(isset($_GET['id'])){
    $id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);

    $query = "SELECT * FROM users WHERE id=$id";
    $result = mysqli_query($connection, $query);
    $user = mysqli_fetch_assoc($result);
    //kullanııcıyı bulma
    if(mysqli_num_rows($result) == 1) {
        $avatar_name = $user['avatar'];
        $avatar_path = '../images/' . $avatar_name;
        //resim varsa sil
        if($avatar_path){
            unlink($avatar_path);
        }
    }
    
    //postları silme
    $resim_query = "SELECT resim FROM posts WHERE author_id=$id"; 
    $resim_result = mysqli_query($connection, $resim_query);
    if(mysqli_num_rows($resim_result) > 0){
        while ( $resim = mysqli_fetch_assoc($resim_result)) {
            $resim_path = '../images/' . $resim['resim'];
            //images dosyasında resim varsa sil
            if($resim_path){
                unlink($resim_path);
            }

        }
    }





    //databaseden kullanıcı silme
    $delete_user_query = "DELETE FROM users WHERE id=$id";
    $delete_user_result = mysqli_query($connection, $delete_user_query);
    
    if(mysqli_errno($connection)){
        $_SESSION['delete-user'] = "Silinemedi '{$user['firstname']} '{$user['lastname']}'";

    }
    else{
        $_SESSION['delete-user-success'] = "{$user['firstname']} {$user['lastname']} başarıyla silinmiştir";
    }
}
header('location: ' . ROOT_URL . 'admin/manage-users.php');
die();