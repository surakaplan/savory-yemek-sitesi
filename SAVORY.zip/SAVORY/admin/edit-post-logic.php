<?php
require 'config/database.php';

if(isset($_POST['submit'])) {
    $id = filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT);
    $eski_resim_name = filter_var($_POST['eski_resim_name'], FILTER_SANITIZE_SPECIAL_CHARS);
    $title = filter_var($_POST['title'], FILTER_SANITIZE_SPECIAL_CHARS);
    $body = filter_var($_POST['body'], FILTER_SANITIZE_SPECIAL_CHARS);
    $category_id = filter_var($_POST['category'], FILTER_SANITIZE_NUMBER_INT);
    $is_featured = filter_var($_POST['is_featured'], FILTER_SANITIZE_NUMBER_INT);
    $resim = $_FILES['resim'];

    //kontrol edilmemişse is featured
    $is_featured = $is_featured == 1 ?: 0;

    //verileri dogrulama
    if(!$title) {
        $_SESSION['edit-post'] ="Tarif güncellenemedi. Tekrar deneyin";
    }
    elseif(!$category_id){
        $_SESSION['edit-post'] = "Tarif güncellenemedi. Tekrar deneyin";
    }
    elseif(!$body){
        $_SESSION['edit-post'] = "Tarif güncellenemedi. Tekrar deneyin";
    }
    else{
        //yeni resim varsa ilk resmi sil
        if($resim['name']){
           $eski_resim_path = '../images/' . $eski_resim_name;
           if ($eski_resim_path) {
            unlink($eski_resim_path);
           }
        
           //YENİ RESİM
        $time = time(); //benzersiz isim yapma
        $resim_name = $time . $resim['name'];
        $resim_tmp_name = $resim['tmp_name'];
        $resim_destination_path = '../images/' . $resim_name;

        //Resim olduguna emin ol
        $allowed_files = ['png','jpg','jpeg'];
                $extention = explode('.', $resim_name);
                $extention = end($extention);

                if(in_array($extention,$allowed_files)){
                    //resim boyutu 2mb+ olamaz
                    if($resim['size'] < 2000000) {
                        //resim yükleme
                        move_uploaded_file($resim_tmp_name, $resim_destination_path);
                    }
                    else{
                        $_SESSION['edit-post'] = "Tarif güncellenemedi. Resim boyutu çok büyük, 2mb'dan küçük olmalı";
                    }
                }
                else{
                    $_SESSION['edit-post'] = "Tarif güncellenemedi. Resim uzantısı png, jpg ya da jpeg olmalıdır";
                }
        
            }

    }    
    
    if($_SESSION['edit-post']){
        header('location: ' . ROOT_URL . 'admin/');
        die();
    }
    
    else{
        // eger bu gönderi öne cıkmıssa(1) diger hepsini 0 yap
        if($is_featured == 1){
        $zero_all_is_featured_query = "UPDATE posts SET is_featured=0";
        $zero_all_is_featured_result = mysqli_query($connection, $zero_all_is_featured_query);

        }
        //resim güncellediyse isim ver olmazsa adını koru
        $resim_to_insert = $resim_name ?? $eski_resim_name;
        
        $query = "UPDATE posts SET title='$title', body='$body', resim='$resim_to_insert', category_id=$category_id, is_featured=$is_featured WHERE id=$id LIMIT 1"; 
        $result = mysqli_query($connection, $query);
    }
    if(!mysqli_errno($connection)) {
        $_SESSION['edit-post-success'] = "Tarif başarıyla güncellendi";
        
    }
}

header('location: ' . ROOT_URL . 'admin/');
die();
