<?php 
include 'partials/header.php';

?>

    <section class="contact__page">
        <h2>iletişim özet</h2>
    </section>







<?php 
include 'partials/footer.php';

?>