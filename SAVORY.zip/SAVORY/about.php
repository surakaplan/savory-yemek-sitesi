<?php 
include 'partials/header.php';

?>


    <section class="about__page">
        <h3>İster tecrübeli bir şef olun ya da tutkulu bir ev aşçısı, damak tadınızı harekete geçirmek ve size en iyi deneyimi sunmak için buradayız.
            Tarif koleksiyonumuz çok çeşitli mutfakları kapsamaktadır. Rahatlatıcı klasiklerden yenilikçi füzyon yemeklerine kadar.
            Her tarif özenle hazırlanmış, test edilmiş ve adım adım talimatlarla birlikte sunularak acemi aşçıların bile yaratıcı şeyler yapabilmesini sağlar. Yemek pişirmenin insanları bir araya getiren bir sanat olduğuna inanıyoruz ve
            amacımız, mutfak yaratıcılığınızı keşfetmeniz ve her yemeği bir şaheser haline getirmeniz için sizi güçlendirmektir. Bu yüzden gelin, çeşitli tarif koleksiyonumuzu keşfedin ve enfes bir gastronomi deneyimine başlayalım!</p>
</h3>
    </section>







<?php 
include 'partials/footer.php';

?>